<?php
    class controlador{
        private $url_servicio;
        public $datos, $objetoJSON, $salida;

        public function __construct(){
            $this->url_servicio = "http://localhost/app_web/index.php";
            $this->objetoJSON = array();
            $this->datos = array();
            }

            function enviarPeticionPost(){
              $clienteCurl = curl_init($this->url_servicio);
              curl_setopt($clienteCurl, CURLOPT_RETURNTRANSFER, true);
              curl_setopt($clienteCurl, CURLOPT_POST, true);
              curl_setopt($clienteCurl, CURLOPT_POSTFIELDS,$this->datos);
              $respuesta = curl_exec($clienteCurl);
              curl_close($clienteCurl);
              $this->objetoJSON = json_decode($respuesta);

              }
            function obtenerRegistros(){
              $filtro = "";
              if(isset($_GET["filtro"])){
                  $filtro = $_GET["filtro"];
              }
              $parametros = array("accion"=>"todos","filtro"=>$filtro);
              $this->datos=$parametros;
              $this->enviarPeticionPost();
              $aResultado = $this->objetoJSON;


              $resultado = "
              <form method='get' action='index.php' class='form'>
              <input type='hidden' value='mostrar' name='accion'>
                Introduzca su criterio de busqueda: <br><br><input type='text' name='filtro' class='label'><br><br>
                <input type='submit' value='Buscar Datos' class='boton'>
              </form>
              <table>
              <tr>
                <td width='50px'class='form'>Carnet</td>
                <td width='150px'class='form'>Nombre</td>
                <td width='150px'class='form'>Apellido</td>
                <td width='150px'class='form'>Departamento</td>
                <td width='150px'class='form'>Municipio</td>
                <td width='90px'class='form'>Opciones</td><br>
              </tr>";
              $n=0;
                foreach($aResultado as $arregloItem){
                    if(is_array($arregloItem)){
                    foreach($arregloItem as $fila){
                      $n++;
                      $resultado .= "
                      <tr class='form'>
                        <td >". $fila->carnet . "</td>
                        <td >". $fila->nombre . "</td>
                        <td > ". $fila->apellido . "</td>
                        <td>". $fila->departamento . "</td>
                        <td >". $fila->municipio . "</td>
                        <td>
                          	<a href='index.php?accion=edit&carnet=". $fila->carnet ."'>Modificar</a>
                            <a href=\"javascript:eliminar('".$fila->carnet ."');\" >Eliminar</a>
                            </td>
                            </tr>
                      ";
                    }
                  }else{
                      $resultado .= "<tr><td colspan='4'>$arregloItem</td></tr>";
                  }

              }
              $resultado .= "</table>";
              $this->salida = $resultado;
            }
   }
 ?>
 <style type="text/css">
       .boton{
         display: block;
         background: #B22222;
         padding: 1em;
         border-radius: 150px;
         width: 200px;
         text-align: center;
         color: white;
         text-decoration: none;
         margin: inherit;
       }
       .morado{
         color: #6600cc;
         font-weight: 600;
         font-size: 30px;
       }
       .label{
       margin: 0px;
       width: 150px;
       font    : .9em/1.5em "handwriting";
       border  : none;
       padding : 0 10px;
       margin  : 0;
       width   : 240px;
       background: none;
       background   : rgba(0,0,0,.1);
       border-radius: 5px;
       }
       .form{
        width:500px;
        font:normal 13px Arial;
        text-align:center;
        border-collapse:collapse;
       }
 </style>
