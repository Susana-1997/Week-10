<?php
{

}else if(accion=="del"){
  $carnet = $_GET["carnet"];
  $parametros = array(
    'accion' => "eliminar", 'carnet' => $carnet
  );
$objetoCliente->datos=$parametros;
$objetoCliente->enviarPeticionPost();
$aResultado = $objetoCliente->objetoJSON;
if($aResultado->estado=="1"){
    echo "<script>
    location.replace('index.php?accion=mostrar');</script>";
}else{
  echo "<span style='color:red;'>
  Ha ocurrido un error: ". $aResultado->mensaje ."</span>";
}
}


}else if($accion=="edit"){
  $carnet = "";
  $nombre = "";
  $apellido = "";
  $departamento = "";
  $municipio = "";
  if(isset($_GET["carnet"])){
    $carnet = $_GET["carnet"];
    $parametros = array('accion' => "ver", 'carnet' => $carnet);
    $objetoCliente->datps=$parametros;
    $objetoCliente->enviarPeticionPost();
    $aResultado = $objetoCliente->$objetoJSON;
    $nombre = $aResultado->items[0]->nombre;
    $apellido = $aResultado->items[0]->apellido;
    $departamento = $aResultado->items[0]->departamento;
    $municipio = $aResultado->items[0]->municipio;



  }
}





 ?>
