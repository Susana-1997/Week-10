<?php
  require("controlador/controlador.php");
  $objetoCliente = new controlador();
  $accion = "";
    if(isset($_GET["accion"])){
      $accion = $_GET["accion"];
    }
    echo "<ul class='ul'>
              <li><a href='index.php?accion=mostrar'>Mostrar Todos</a></li><br>
              <li><a href='index.php?accion=nuevo'>Nuevo Registro</a></li><br>
          </ul><hr>
            <script>
              function eliminar(id){
                if(confirm(\"Esta seguro que desea eliminar esto?\")){
                  location.replace('index.php?accion=del&&carnet='+id);
                }
              }
              </script>
          ";

    if($accion=="mostrar"){
      $objetoCliente->obtenerRegistros();
      echo $objetoCliente->salida;
    }else if($accion=="nuevo"){
      if($_POST){
        $carnet = $_POST["carnet"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $departamento = $_POST["departamento"];
        $municipio = $_POST["municipio"];
        $parametros = array(
                'accion' => "agregar", 'carnet' => $carnet,
                'nombre' => $nombre, 'apellido' => $apellido,
                'departamento' => $departamento,
                'municipio' => $municipio,
        );
        $objetoCliente->datos=$parametros;
        $objetoCliente->enviarPeticionPost();
        $aResultado = $objetoCliente->objetoJSON;
        if($aResultado->estado=="1"){
            echo "<script>
            location.replace('index.php?accion=mostrar');</script>";

        }else{
          echo "<span style='color:red;'>
          Ha ocurrido un error: ". $aResultado->mensaje ."</span>";
        }
      }
      echo "
      <form method='post' action='index.php?accion=nuevo' class='form'>
      <label>Carnet: <input type='number' name='carnet' class='label'></label><br><br>
      <label>Nombre: <input type='text' name='nombre' class='label'></label><br><br>
      <label>Apellido: <input type='text' name='apellido' class='label'></label><br><br>
      <label>Departamento: <input type='text' name='departamento' class='label'></label><br><br>
      <label>Municipio: <input type='text' name='municipio' class='label'></label><br><br>
      <input type='submit' value='Agregar Nuevo' class='boton'><br>
      </form>";
    }else if($accion=="del"){
      $carnet = $_GET["carnet"];
      $parametros = array(
        'accion' => "eliminar", 'carnet' => $carnet
      );
    $objetoCliente->datos=$parametros;
    $objetoCliente->enviarPeticionPost();
    $aResultado = $objetoCliente->objetoJSON;
    if($aResultado->estado=="1"){
        echo "<script>
        location.replace('index.php?accion=mostrar');</script>";
    }else{
      echo "<span style='color:red;'>
      Ha ocurrido un error: ". $aResultado->mensaje ."</span>";
    }
    }else if($accion=="edit"){
      $carnet = "";
      $nombre = "";
      $apellido = "";
      $departamento = "";
      $municipio = "";
      if(isset($_GET["carnet"])){
        $carnet = $_GET["carnet"];
        $parametros = array('accion' => "ver", 'carnet' => $carnet);
        $objetoCliente->datos=$parametros;
        $objetoCliente->enviarPeticionPost();
        $aResultado = $objetoCliente->objetoJSON;
        $nombre = $aResultado->items[0]->nombre;
        $apellido = $aResultado->items[0]->apellido;
        $departamento = $aResultado->items[0]->departamento;
        $municipio = $aResultado->items[0]->municipio;
    }
    if($_POST){
      $carnet = $_POST["carnet"];
      $nombre = $_POST["nombre"];
      $apellido = $_POST["apellido"];
      $departamento = $_POST["departamento"];
      $municipio = $_POST["municipio"];
      $parametros = array(
              'accion' => "modificar", 'carnet' => $carnet,
              'nombre' => $nombre, 'apellido' => $apellido,
              'departamento' => $departamento,
              'municipio' => $municipio,
      );
      $objetoCliente->datos=$parametros;
      $objetoCliente->enviarPeticionPost();
      $aResultado = $objetoCliente->objetoJSON;
      if($aResultado->estado=="1"){
          echo "<script>
          location.replace('index.php?accion=mostrar');</script>";

      }else{
        echo "<span style='color:red;'>
        Ha ocurrido un error: ". $aResultado->mensaje ."</span>";
      }
    }
    echo "
    <form method='post' action='index.php?accion=edit' class='form'>
    <h1>Modificar registro</h1>
    <label>Carnet: <input type='hidden' name='carnet' class='label' readondly value='$carnet'></label><br><br>
    <label>Nombre: <input type='text' name='nombre' class='label' value='$nombre'></label><br><br>
    <label>Apellido: <input type='text' name='apellido' class='label' value='$apellido'></label><br><br>
    <label>Departamento: <input type='text' name='departamento' class='label' value='$departamento'></label><br><br>
    <label>Municipio: <input type='text' name='municipio' class='label' value='$municipio'></label><br><br>
    <input type='submit' value='Modificar' class='boton'><br>
    </form>";
    }
?>
<style type="text/css">
      .boton{
        display: block;
        background: #B22222;
        padding: 1em;
        border-radius: 150px;
        width: 200px;
        text-align: center;
        color: white;
        text-decoration: none;
      }
        .label{
        font    : .9em/1.5em "handwriting";
        border  : none;
        padding : 0 10px;
        margin  : 0;
        width   : 240px;
        background: none;
        background   : rgba(0,0,0,.1);
        border-radius: 5px;
        }
      .form{
      	width:400px;
      	padding:16px;
      	border-radius:10px;
      	margin:auto;
      	background-color:#D2B48C;
      }
      .ul{
        width:300px;
        border-radius:10px;
        margin: inherit;
        background-color:#D2B48C;
        text-align: left;

      }
</style>
