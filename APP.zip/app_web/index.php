<?php
  include_once("ApiEstudiantes.php");
  $api = new ApiEstudiantes();
  $accion = "";
  if(isset($_GET["accion"])){
      $accion = $_GET["accion"];
  }

  if(isset($_POST["accion"])){
    $accion = $_POST["accion"];
  }

  if($accion=="agregar"){
    if($_POST){
      $nombre = $_POST["nombre"];
      $apellido = $_POST["apellido"];
      $departamento = $_POST["departamento"];
      $municipio = $_POST["municipio"];
      $carnet = $_POST["carnet"];
      $item = array(
        'nombre' => $nombre,
        'apellido' => $apellido,
        'departamento' => $departamento,
        'municipio' => $municipio,
        'carnet' => $carnet
      );
      $api->addEstudiante($item);
    }
  }else if($accion=="modificar"){
    if($_POST){
      $nombre = $_POST["nombre"];
      $apellido = $_POST["apellido"];
      $departamento = $_POST["departamento"];
      $municipio = $_POST["municipio"];
      $carnet = $_POST["carnet"];
      $item = array(
        'nombre' => $nombre,
        'apellido' => $apellido,
        'departamento' => $departamento,
        'municipio' => $municipio,
        'carnet' => $carnet
      );
      $api->editEstudiante($item);
    }
  }else if($accion=="eliminar"){
    if($_POST){
      $carnet = $_POST["carnet"];
      $api->deleteEstudiante($carnet);
    }
  }else if($accion=="ver"){
      //mostrar un estudiante especifico
      if(isset($_POST["carnet"])){
        $carnet = $_POST["carnet"];
        $api->getEstudiante($carnet);
      }
    }else if($accion=="todos"){
      //mostrar todo
      $filtro = "";
      if(isset($_POST["filtro"])){
          $filtro = $_POST["filtro"];
      }
      $api->getTodosEstudiantes($filtro);
    }else{
      $api->mostrarError("OPCION NO EXISTENTE");
    }
?>
