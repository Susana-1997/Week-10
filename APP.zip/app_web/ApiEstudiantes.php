<?php
include_once("ClaseEstudiantes.php");
class ApiEstudiantes{
    private $error;
    function getTodosEstudiantes($a){
        $objEstudiante = new ClaseEstudiantes();
        $arregloEstudiantes = array();
        $arregloEstudiantes["items"] = array();
        $resultado = $objEstudiante->obtenerEstudiantes($a);
        if($resultado->rowCount()){
          while ($cadaFila = $resultado->fetch(PDO::FETCH_ASSOC)){
              $items=array(
                "carnet" => $cadaFila['carnet'],"nombre" => $cadaFila['nombre'],"municipio" => $cadaFila['municipio'],
                "apellido" => $cadaFila['apellido'],"departamento"=>$cadaFila["departamento"]);
            array_push($arregloEstudiantes["items"], $items);
          }
          $this->mostrarResultado($arregloEstudiantes);
        }else{
            $this->mostrarError('Sin Registros que Mostrar');
        }
        }

        function mostrarError($mensaje){
            echo json_encode(array('mensaje' => $mensaje));
        }

        function getError(){
            return $this->error;
          }

        function mostrarResultado($array){
            echo json_encode($array);
        }

        function getEstudiante($id){
          $objEstudiante = new ClaseEstudiantes();
          $arregloEstudiantes = array();
          $arregloEstudiantes["items"] = array();
          $resultado = $objEstudiante->datosEstudiante($id);
          if ($resultado->rowCount() == 1){
            $row =  $resultado->fetch();
            $item=array(
              "carnet" => $row['carnet'],
              "nombre" => $row['nombre'],
              "apellido" => $row['apellido'],
              "departamento" => $row['departamento'],
              "municipio" => $row['municipio'],
            );
            array_push($arregloEstudiantes["items"], $item);
            $this->mostrarResultado($arregloEstudiantes);
          }else{
            $this->mostrarError('NO EXISTE ESTE REGISTRO');
          }
        }

        function addEstudiante($item){
            $objEstudiante = new ClaseEstudiantes();
            $resultado = $objEstudiante->nuevoEstudiante($item);
            $this->mostrarResultado($resultado);
          }

        function editEstudiante($item){
          $objEstudiante = new ClaseEstudiantes();
          $resultado = $objEstudiante->modificarEstudiante($item);
          $this->mostrarResultado($resultado);
        }

        function deleteEstudiante($id){
          $objEstudiante = new ClaseEstudiantes();
          $resultado = $objEstudiante->eliminarEstudiante($id);
          $this->mostrarResultado($resultado);
        }
}
 ?>
