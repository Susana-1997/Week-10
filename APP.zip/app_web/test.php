<?php
    //URL del servicio web
    $clienteCurl = curl_init('http://localhost/app_web/index.php');
    //Tipo de peticion en este caso transferencia de datos
    curl_setopt($clienteCurl, CURLOPT_RETURNTRANSFER, true);
    //Datos a enviar (Arreglo de datos)
    $datos = array(
        "accion" => "agregar","nombre" => "Juan","carnet" => "5",
        "apellido" => "Perez","departamento" => "San Miguel",
        "municipio" => "San Miguel"
    );
    //Establecemos el metodo de envio de datos(POST)
    curl_setopt($clienteCurl, CURLOPT_POST, true);
    //Establecemos los datos a enviar(Arreglo de datos)
    curl_setopt($clienteCurl, CURLOPT_POSTFIELDS, $datos);
    //Enviamos la peticion
    $respuesta = curl_exec($clienteCurl);
    //Cerramos la peticion
    curl_close($clienteCurl);
    //Obtenemos la informacion que nos devuelve el WS
    //Lo parseamos (convertimos a un tipo de arreglo)
    $aMensajes = json_decode($respuesta);
    echo "Resultado: ".$aMensajes->estado."<br>";
    echo "Mensaje Retornado: ".$aMensajes->mensaje;
?>
