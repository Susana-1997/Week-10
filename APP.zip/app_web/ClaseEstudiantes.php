<?php
include_once("config/config.php");

  class ClaseEstudiantes extends MiConexion{
    //INICIO obtenerEstudiantes
    function obtenerEstudiantes($a){
      $consulta = "SELECT * FROM estudiantes WHERE (carnet LIKE '%$a%' OR apellido LIKE '%$a%' OR nombre LIKE '%$a%')";
      $query = $this->conectar()->query($consulta);
      return $query;
    }
    //FIN obtenerEstudiantes

    //INICIO datosEstudiante
    function datosEstudiante($id){
      $comando = "SELECT * FROM estudiantes WHERE carnet = :elCarnet";
      $query = $this->conectar()->prepare($comando);
      $query->execute(['elCarnet' => $id]);
      return $query;
    }
    //FIN datosEstudiante

    //INICIO nuevoEstudiante
    function nuevoEstudiante($aEstudiante){
      $aMensaje = array();
      try{
        $comando = "INSERT INTO estudiantes (carnet,nombre, apellido,departamento,municipio)
        VALUES (:carnet, :nombre, :apellido, :departamento, :municipio)";
        $query = $this->conectar()->prepare($comando);
        $query->execute(['carnet' => $aEstudiante['carnet'],
                        'nombre' => $aEstudiante['nombre'],
                        'apellido' => $aEstudiante['apellido'],
                        'departamento' => $aEstudiante['departamento'],
                        'municipio' => $aEstudiante['municipio']]);
      if($query->errorCode()=="00000"){
        $aMensaje["estado"] = "1";
        $aMensaje["mensaje"] = "Datos Almacenados con EXITO";
      }else{
        $aMensaje["estado"] = "0";
        $aMensaje["mensaje"] = "Error interno: ". $query->errorInfo()[2];
      }
    }catch(Exception $e){
      $aMensaje["estado"] = "0";
      $aMensaje["mensaje"] = "Error Interno: ". $e->getMessage();
    }
      return $aMensaje;
    }
    //FIN nuevoEstudiante
    //INICIO modificarEstudiante
    function modificarEstudiante($aEstudiante){
        $aMensaje = array();
        try{
          $comando = "UPDATE estudiantes SET nombre=:nombre, apellido=:apellido, departamento=:departamento,
          municipio=:municipio WHERE carnet=:carnet";
          $query = $this->conectar()->prepare($comando);
          $query->execute(['carnet' => $aEstudiante['carnet'],
                          'nombre' => $aEstudiante['nombre'],
                          'apellido' => $aEstudiante['apellido'],
                          'departamento' => $aEstudiante['departamento'],
                          'municipio' => $aEstudiante['municipio']]);
        if($query->errorCode()=="00000"){
          $aMensaje["estado"] = "1";
          $aMensaje["mensaje"] = "Datos Modificados con EXITO";
        }else{
          $aMensaje["estado"] = "0";
          $aMensaje["mensaje"] = "Error interno: ". $query->errorInfo()[2];
          }
        }catch(Exception $e){
          $aMensaje["estado"] = "0";
          $aMensaje["mensaje"] = "Error Interno: ".$e->getMessage();
        }
        return $aMensaje;
}
  //  FIN modificarEstudiante
  //INICIO eliminarEstudiante
    function eliminarEstudiante($id){
      $aMensaje = array();
      try{
        $comando = "DELETE FROM estudiantes WHERE carnet=:carnet";
        $query = $this->conectar()->prepare($comando);
        $query->execute(['carnet' => $id]);
        if($query->errorCode()=="00000"){
          $aMensaje["estado"] = "1";
          $aMensaje["mensaje"] = "Datos Eliminados con EXITO";
        }else{
          $aMensaje["estado"] = "0";
          $aMensaje["mensaje"] = "Error interno: ". $query->errorInfo()[2];
        }
      }catch(Exception $e){
        $aMensaje["estado"] = "0";
        $aMensaje["mensaje"] = "Error interno: ". $e->getMessage();
      }
      return $aMensaje;
    }
    //FIN eliminarEstudiante
  }
 ?>
